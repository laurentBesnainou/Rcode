server <- function(input, output) { 
  
  output$mon_vote_connaissance <- renderText({
    
    my_connaissance_answer <- questionnaire_connaissance %>% 
      filter(Associe == input$associe_id,
             ID_consultant == input$consultant_id)
    
    my_connaissance_answer[["response"]]
    
  })
  
  output$mon_radar_asso <- renderPlot({
    
    qualite_asso_indiv <- questionnaire_qualites %>% 
      select(ID_consultant,
             Associe, 
             qualite,
             score) %>% 
      filter(ID_consultant == input$consultant_id,
             Associe == input$associe_id)
    
    qualite_asso_indiv %>%
      mutate(qualite = factor(qualite)) %>% 
      ggplot(aes(x = qualite, y = score)) +
      geom_col(alpha = 0.5, 
               width = 1, show.legend = FALSE, color = "white", aes(fill = factor(score))) +
      geom_hline(yintercept = seq(0, 3, by = 1),
                 colour = "#949494", size = 0.5, lty = 3) +
      geom_vline(xintercept = seq(0.5, 3.5, 1),
                 colour = "#949494", size = 0.4, lty = 1) +
      coord_polar() +
      scale_fill_manual(values = c("1"= "#56B4E9", "2" = "#E69F00","3"  ="#009E73")) +
      scale_y_continuous(
        limits = c(0, 3), 
        breaks = c(1, 2, 3, 4)) + 
      labs(x = "", y = "") + 
      theme(
        panel.background = element_rect(fill = "#FFFFFF"),
        plot.background = element_rect(fill = "#FFFFFF"),
        strip.background = element_rect(fill = "#FFFFFF"),
        strip.text = element_text(size = 15),
        panel.grid = element_blank(),
        axis.ticks = element_blank(),
        axis.text.y = element_blank(),
        axis.text.x = element_text(size = 7),
        panel.spacing = grid::unit(2, "lines"))
  })
  
  output$global_radar_asso <- renderPlot({
    
    qualite_asso_global <- questionnaire_qualites %>% 
      select(ID_consultant,
             Associe, 
             qualite,
             score) %>% 
      filter(Associe == input$associe_id) %>% 
      group_by(qualite) %>% 
      summarise(score = mean(score))%>%
      mutate(couleur= ifelse(score<1.6,1,
                             ifelse(score<2.33,2,3))) %>%
      mutate(couleur= factor(couleur))
    
    qualite_asso_global %>%
      mutate(qualite = factor(qualite)) %>% 
      ggplot(aes(x = qualite, y = score)) +
      geom_col(alpha = 0.5, 
               width = 1, show.legend = FALSE, color = "white", aes(fill = couleur)) +
      geom_hline(yintercept = seq(0, 3, by = 1),
                 colour = "#949494", size = 0.5, lty = 3) +
      geom_vline(xintercept = seq(0.5, 3.5, 1),
                 colour = "#949494", size = 0.4, lty = 1) +
      coord_polar() +
      scale_fill_manual(values = c("1"= "#56B4E9", "2" = "#E69F00","3"  ="#009E73")) +
      scale_y_continuous(
        limits = c(0, 3), 
        breaks = c(1, 2, 3, 4)) + 
      labs(x = "", y = "") + 
      theme(
        panel.background = element_rect(fill = "#FFFFFF"),
        plot.background = element_rect(fill = "#FFFFFF"),
        strip.background = element_rect(fill = "#FFFFFF"),
        strip.text = element_text(size = 15),
        panel.grid = element_blank(),
        axis.ticks = element_blank(),
        axis.text.y = element_blank(),
        axis.text.x = element_text(size = 7),
        panel.spacing = grid::unit(2, "lines"))
  })
  
  output$know_radar_asso <- renderPlot({
    
    knows_asso <- questionnaire_connaissance %>% 
      filter(Associe == input$associe_id,
             response == "Je connais") %>% 
      select(ID_consultant)
    
    qualite_asso_know <- questionnaire_qualites %>% 
      select(ID_consultant,
             Associe, 
             qualite,
             score) %>% 
      filter(Associe == input$associe_id) %>% 
      inner_join(knows_asso, by = "ID_consultant") %>% 
      group_by(qualite) %>% 
      summarise(score = mean(score)) %>%
      mutate(couleur= ifelse(score<1.6,1,
                             ifelse(score<2.33,2,3))) %>%
      mutate(couleur= factor(couleur))
    
    qualite_asso_know %>%
      mutate(qualite = factor(qualite)) %>% 
      ggplot(aes(x = qualite, y = score)) +
      geom_col(alpha = 0.5, 
               width = 1, show.legend = FALSE, color = "white", aes(fill = couleur)) +
      geom_hline(yintercept = seq(0, 3, by = 1),
                 colour = "#949494", size = 0.5, lty = 3) +
      geom_vline(xintercept = seq(0.5, 3.5, 1),
                 colour = "#949494", size = 0.4, lty = 1) +
      coord_polar() +
      scale_fill_manual(values = c("1"= "#56B4E9", "2" = "#E69F00","3"  ="#009E73"))+
      scale_y_continuous(
        limits = c(0, 3), 
        breaks = c(1, 2, 3, 4)) + 
      labs(x = "", y = "") + 
      theme(
        panel.background = element_rect(fill = "#FFFFFF"),
        plot.background = element_rect(fill = "#FFFFFF"),
        strip.background = element_rect(fill = "#FFFFFF"),
        strip.text = element_text(size = 15),
        panel.grid = element_blank(),
        axis.ticks = element_blank(),
        axis.text.y = element_blank(),
        axis.text.x = element_text(size = 7),
        panel.spacing = grid::unit(2, "lines"))
  })
  
  output$dont_know_radar_asso <- renderPlot({
    
    dont_knows_asso <- questionnaire_connaissance %>% 
      filter(Associe == input$associe_id,
             response == "Je ne connais pas") %>% 
      select(ID_consultant)
    
    qualite_asso_dont_know <- questionnaire_qualites %>% 
      select(ID_consultant,
             Associe, 
             qualite,
             score) %>% 
      filter(Associe == input$associe_id) %>% 
      inner_join(dont_knows_asso, by = "ID_consultant") %>% 
      group_by(qualite) %>% 
      summarise(score = mean(score)) %>%
      mutate(couleur= ifelse(score<1.6,1,
                             ifelse(score<2.33,2,3))) %>%
      mutate(couleur= factor(couleur))
    
    qualite_asso_dont_know %>%
      mutate(qualite = factor(qualite)) %>% 
      ggplot(aes(x = qualite, y = score)) +
      geom_col(alpha = 0.5, 
               width = 1, show.legend = FALSE, color = "white", aes(fill = couleur)) +
      geom_hline(yintercept = seq(0, 3, by = 1),
                 colour = "#949494", size = 0.5, lty = 3) +
      geom_vline(xintercept = seq(0.5, 3.5, 1),
                 colour = "#949494", size = 0.4, lty = 1) +
      coord_polar() +
      
      scale_fill_manual(values = c("1"= "#56B4E9", "2" = "#E69F00","3"  ="#009E73"))+
      scale_y_continuous(
        limits = c(0, 3), 
        breaks = c(1, 2, 3, 4)) + 
      labs(x = "", y = "") + 
      theme(
        panel.background = element_rect(fill = "#FFFFFF"),
        plot.background = element_rect(fill = "#FFFFFF"),
        strip.background = element_rect(fill = "#FFFFFF"),
        strip.text = element_text(size = 15),
        panel.grid = element_blank(),
        axis.ticks = element_blank(),
        axis.text.y = element_blank(),
        axis.text.x = element_text(size = 7),
        panel.spacing = grid::unit(2, "lines"))
  })
}